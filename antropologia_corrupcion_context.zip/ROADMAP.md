
# ROADMAP SUGERIDO

## FASE 1 — Normalización
- Estructurar ontología
- Crear taxonomía
- Separar evidencia vs hipótesis
- Organizar markdowns

## FASE 2 — Infraestructura visual
- Grafo principal
- Timeline
- Panel de filtros
- Navegación semántica

## FASE 3 — Evidencia y trazabilidad
- Sistema de referencias
- Indexación de citas
- Metadata documental

## FASE 4 — Capa doctoral
- Marco metodológico
- Papers
- Referencias APA
- Discusión comparada internacional

## FASE 5 — Plataforma pública
- Observatorio
- Archivo vivo
- Exportaciones PDF
- Dashboard investigativo
