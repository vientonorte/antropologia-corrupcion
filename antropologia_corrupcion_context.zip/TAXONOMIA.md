
# TAXONOMÍA INICIAL

| Código | Tipo |
|---|---|
| CON | Concepto |
| REF | Referencia |
| ETH | Hallazgo etnográfico |
| INF | Infraestructura |
| DAT | Flujo de datos |
| POD | Relación de poder |
| FIS | Fiscalización |
| RSK | Riesgo |
| OBS | Observación analítica |

# EJEMPLO

| Fragmento | Tags |
|---|---|
| experiencia humana como materia prima | CON, POD |
| extracción y predicción | DAT |
| modificación conductual | POD |
| cloud y vendors | INF |
| fiscalización fragmentada | FIS |
