
# PROMPT PARA GITHUB COPILOT / CODEX

Actúa como arquitecto de información, investigador UX crítico y desarrollador full-stack especializado en:
- visualización de grafos,
- OSINT,
- antropología digital,
- infraestructura crítica,
- civic tech,
- análisis sociotécnico.

## Objetivo
Evolucionar el proyecto "Antropología de la Corrupción en Chile" hacia:
- observatorio sociotécnico,
- archivo vivo,
- plataforma de investigación doctoral,
- sistema de trazabilidad de relaciones entre infraestructura, poder y datos.

## Requerimientos funcionales

### Ontología base
Crear tipos de nodos:
- Institución
- Actor
- Infraestructura
- Base de datos
- Documento
- Evento
- Fiscalización
- Vendor
- Riesgo
- Sociedad civil

### Relaciones
- financia
- integra
- monitorea
- fiscaliza
- terceriza
- replica
- almacena
- analiza
- predice
- conecta

### Visualizaciones
Implementar:
- grafo interactivo
- Sankey
- timelines
- capas por taxonomía
- filtros dinámicos
- visualización de evidencia

### Sistema de evidencia
Cada nodo debe permitir:
- fuente
- fecha
- tipo de evidencia
- nivel de confianza
- trazabilidad documental

### UX/UI
Estética:
- archivo crítico
- observatorio
- infraestructura
- investigación académica

Debe existir:
- modo exploración
- modo lectura académica
- onboarding epistemológico
- accesibilidad WCAG 2.2

### Arquitectura técnica sugerida
- Next.js o Astro
- D3.js / Sigma.js / Cytoscape
- Markdown como fuente documental
- JSON-LD para relaciones
- GitHub Pages
- CI/CD GitHub Actions

### Principios
- privacy-by-design
- transparencia metodológica
- auditabilidad
- separación entre hipótesis y evidencia
- diseño inclusivo
- trazabilidad

## Resultado esperado
Convertir el repositorio en una plataforma académica y visual capaz de:
- mapear relaciones de poder,
- documentar infraestructura,
- visualizar opacidad institucional,
- y sostener investigación doctoral verificable.
