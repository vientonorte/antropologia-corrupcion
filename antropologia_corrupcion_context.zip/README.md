
# Antropología de la Corrupción en Chile — Contexto Estratégico

## Objetivo
Este paquete resume análisis conceptuales, metodológicos y arquitectónicos para continuar el proyecto
"Antropología de la Corrupción en Chile" usando GitHub Copilot/Codex.

## Dirección epistemológica
La investigación evoluciona desde:
- corrupción administrativa
hacia:
- antropología de infraestructuras de poder,
- capitalismo de vigilancia,
- opacidad sociotécnica,
- gubernamentalidad algorítmica,
- circulación de datos y fiscalización distribuida.

## Autores centrales
- Shoshana Zuboff
- Michel Foucault
- Pierre Bourdieu
- Bruno Latour
- Susan Leigh Star
- Manuel Castells

## Hipótesis principal
La corrupción contemporánea no depende exclusivamente del ocultamiento,
sino de:
- complejidad distribuida,
- fragmentación técnica,
- opacidad operacional,
- externalización de infraestructura,
- asimetría de legibilidad.

## Pregunta de investigación sugerida
¿Cómo las infraestructuras digitales-financieras producen condiciones de opacidad y asimetría de fiscalización en Chile?

## Capas analíticas
1. Poder institucional
2. Infraestructura técnica
3. Circulación de datos
4. Fiscalización
5. Sociedad civil

## Riesgos metodológicos
- Sobreabstracción
- Deriva conspirativa
- Falta de evidencia trazable
- Dependencia excesiva del conocimiento tácito del investigador

## Necesidades inmediatas
- Taxonomía estable
- Sistema de evidencia
- Ontología de nodos y relaciones
- Pipeline de documentación
- Modo lectura académica
- Separación entre hipótesis y evidencia
